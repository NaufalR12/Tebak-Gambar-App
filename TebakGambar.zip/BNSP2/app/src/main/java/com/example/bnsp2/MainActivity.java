package com.example.bnsp2;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity{
    ImageView imageView_satu, imageView_dua, imageView_tiga,imageView_empat, imageView_lima, imageView_enam ;

    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setInisialisasi();
        onClickMantab();
    }

    private void onClickMantab(){
        imageView_satu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { Intent d = new
                    Intent(MainActivity.this, inputActivity.class);
                d.putExtra( "nama_icon", "satu"); startActivity(d);

            }
        });

        imageView_dua.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { Intent d = new
                    Intent(MainActivity.this, inputActivity.class);
                d.putExtra( "nama_icon", "dua"); startActivity(d);

            }
        });

        imageView_tiga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { Intent d = new
                    Intent(MainActivity.this, inputActivity.class);
                d.putExtra( "nama_icon", "tiga"); startActivity(d);

            }
        });

        imageView_empat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { Intent d = new
                    Intent(MainActivity.this, inputActivity.class);
                d.putExtra( "nama_icon", "empat"); startActivity(d);

            }
        });

        imageView_lima.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { Intent d = new
                    Intent(MainActivity.this, inputActivity.class);
                d.putExtra( "nama_icon", "lima"); startActivity(d);

            }
        });

        imageView_enam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { Intent d = new
                    Intent(MainActivity.this, inputActivity.class);
                d.putExtra( "nama_icon", "enam"); startActivity(d);

            }
        });
    }

    private void setInisialisasi(){
        imageView_satu = (ImageView)findViewById(R.id.imageView_satu);
        imageView_dua = (ImageView)findViewById(R.id.imageView_dua);
        imageView_tiga = (ImageView)findViewById(R.id.imageView_tiga);
        imageView_empat = (ImageView)findViewById(R.id.imageView_empat);
        imageView_lima= (ImageView)findViewById(R.id.imageView_lima);
        imageView_enam = (ImageView)findViewById(R.id.imageView_enam);
    }
}