package com.example.bnsp2;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.content.Intent;
import android.widget.ImageView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class inputActivity extends AppCompatActivity {

    ImageView imageView_tebak;
    EditText editText_jawabb;
    Button button_cek;
    String jawaban;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_input);

        setInisialisasi();
        cekIntent();
        onClickJos();
    }

    private void onClickJos(){
        button_cek.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                // Mengambil input pengguna dan mengubahnya menjadi huruf kapital
                String userInput = editText_jawabb.getText().toString().trim().toLowerCase();

                // Membandingkan input pengguna dengan jawaban
                if (userInput.equals(jawaban.toLowerCase())) {
                    Toast.makeText(inputActivity.this, "Selamat Jawaban Anda Benar!", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(inputActivity.this, "Maaf Jawaban Anda Salah!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void cekIntent(){
        Intent cek = getIntent();
        String nama_icon = cek.getStringExtra("nama_icon");

        if (nama_icon != null) {
            if (nama_icon.equalsIgnoreCase("satu")) {
                imageView_tebak.setImageResource(R.drawable.satu);
                jawaban = "satu";
            } else if (nama_icon.equalsIgnoreCase("dua")) {
                imageView_tebak.setImageResource(R.drawable.dua);
                jawaban = "dua";
            } else if (nama_icon.equalsIgnoreCase("tiga")) {
                imageView_tebak.setImageResource(R.drawable.tiga);
                jawaban = "tiga";
            } else if (nama_icon.equalsIgnoreCase("empat")) {
                imageView_tebak.setImageResource(R.drawable.empat);
                jawaban = "empat";
            } else if (nama_icon.equalsIgnoreCase("lima")) {
                imageView_tebak.setImageResource(R.drawable.lima);
                jawaban = "lima";
            } else if (nama_icon.equalsIgnoreCase("enam")) {
                imageView_tebak.setImageResource(R.drawable.enam);
                jawaban = "enam";
            } else {
                // Menangani kasus jika nama_icon tidak dikenali
                Toast.makeText(this, "Icon tidak dikenali", Toast.LENGTH_SHORT).show();
            }
        } else {
            // Menangani kasus jika nama_icon adalah null
            Toast.makeText(this, "nama_icon tidak tersedia", Toast.LENGTH_SHORT).show();
        }
    }

    private void setInisialisasi(){
        imageView_tebak = (ImageView) findViewById(R.id.imageView_tebak);
        editText_jawabb = (EditText) findViewById(R.id.Text_jawab);
        button_cek = (Button) findViewById(R.id.buttonCek);
    }
}
